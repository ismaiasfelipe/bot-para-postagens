"""
Conector Google Drive -> Banco de produtos (IL Variedades)

O QUE ESTE SCRIPT FAZ
----------------------
Le a estrutura REAL de catalogo que ja existe no Google Drive da loja e
monta a lista de produtos automaticamente, no mesmo formato que
gerar_carrossel_gemini.py espera (substituindo o produtos_exemplo.json).

ESTRUTURA REAL JA EXISTENTE NO DRIVE (confirmada em 04/08/2026)
------------------------------------------------------------------
produtos/                                  <- pasta raiz do catalogo
  cama (quarto)/
    lençol casal 4 pçs/
      estampas/            -> fotos cruas do tecido/produto
      produto no ambiente/ -> fotos do produto em cena/decoracao
      fotos variadas/      -> outras fotos soltas
      descrição/           -> Google Doc com ficha tecnica
    colcha preguiada sarja casal-box/
    ... (outros produtos da categoria)
  banho (banheiro)/
  mesa (cozinha)/
  sofá (cortinas, tapetes e adereços)/
  infantil/

Cada pasta de categoria contem varias pastas de produto, e cada pasta de
produto contem as 4 subpastas acima (nem todas tem conteudo em todas ainda).

CONFIGURACAO NECESSARIA (fazer uma unica vez)
------------------------------------------------
1. Acesse https://console.cloud.google.com/
2. Crie um projeto nesse Google Cloud (ou use um existente)
3. Ative a "Google Drive API" (menu APIs e servicos > Ativar APIs e servicos)
4. Crie uma "Conta de servico" (Credenciais > Criar credenciais > Conta de
   servico). De um nome tipo "bot-il-variedades"
5. Depois de criada, gere uma chave: clique na conta de servico > Chaves >
   Adicionar chave > Criar nova chave > formato JSON. Isso baixa um arquivo
   .json -- SALVE ele nesta mesma pasta do projeto com o nome
   "credenciais_drive.json" (e nunca compartilhe/publique esse arquivo)
6. Abra o arquivo .json baixado e copie o valor do campo "client_email"
   (algo tipo bot-il-variedades@nome-projeto.iam.gserviceaccount.com)
7. No Google Drive de verdade, va na pasta "produtos" (a pasta raiz do
   catalogo), clique em Compartilhar, e adicione esse e-mail como "Leitor"
   -- compartilhar so a pasta raiz ja da acesso a tudo dentro dela
8. Pegue o ID da pasta raiz "produtos": abra ela no navegador e copie o
   trecho da URL depois de "folders/"

COMO RODAR
----------
pip install google-api-python-client google-auth --break-system-packages
python conectar_drive.py
"""

import io
import json
from pathlib import Path

from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload

# --- Configuracao ---
ARQUIVO_CREDENCIAIS = "credenciais_drive.json"
ID_PASTA_PRODUTOS = "14HEzU31Lu4ieHCLGgKrDFkHI3Q3lOcOk"  # pasta raiz do catalogo "produtos"
PASTA_DOWNLOAD_LOCAL = Path("banco_local")
PASTA_DOWNLOAD_LOCAL.mkdir(exist_ok=True)

SUBPASTAS_DE_FOTO = ["produto no ambiente", "estampas", "fotos variadas"]
# ordem de preferencia: prioriza foto "no ambiente" (mais bonita pra usar
# como referencia de geracao), depois estampas, depois fotos variadas

SCOPES = ["https://www.googleapis.com/auth/drive.readonly"]


def conectar():
    credenciais = service_account.Credentials.from_service_account_file(
        ARQUIVO_CREDENCIAIS, scopes=SCOPES
    )
    return build("drive", "v3", credentials=credenciais)


def listar_subpastas(servico, id_pasta_pai):
    query = (
        f"'{id_pasta_pai}' in parents "
        "and mimeType = 'application/vnd.google-apps.folder' "
        "and trashed = false"
    )
    resultado = servico.files().list(q=query, fields="files(id, name)").execute()
    return [(f["id"], f["name"]) for f in resultado.get("files", [])]


def listar_imagens(servico, id_pasta):
    query = (
        f"'{id_pasta}' in parents "
        "and (mimeType contains 'image/') "
        "and trashed = false"
    )
    resultado = servico.files().list(
        q=query, fields="files(id, name, mimeType)"
    ).execute()
    return resultado.get("files", [])


def ler_descricao(servico, id_pasta_descricao):
    """Le o conteudo do Google Doc de ficha tecnica, se existir."""
    query = (
        f"'{id_pasta_descricao}' in parents "
        "and mimeType = 'application/vnd.google-apps.document' "
        "and trashed = false"
    )
    resultado = servico.files().list(q=query, fields="files(id, name)").execute()
    arquivos = resultado.get("files", [])
    if not arquivos:
        return ""

    id_doc = arquivos[0]["id"]
    conteudo = servico.files().export(
        fileId=id_doc, mimeType="text/plain"
    ).execute()
    return conteudo.decode("utf-8") if isinstance(conteudo, bytes) else conteudo


def baixar_arquivo(servico, id_arquivo, caminho_destino):
    request = servico.files().get_media(fileId=id_arquivo)
    with io.FileIO(caminho_destino, "wb") as arquivo_local:
        downloader = MediaIoBaseDownload(arquivo_local, request)
        concluido = False
        while not concluido:
            _, concluido = downloader.next_chunk()


def montar_banco_de_produtos() -> dict:
    servico = conectar()
    produtos = []
    contador = 1

    categorias = listar_subpastas(servico, ID_PASTA_PRODUTOS)
    print(f"Encontradas {len(categorias)} categorias no Drive.\n")

    for id_categoria, nome_categoria in categorias:
        produtos_da_categoria = listar_subpastas(servico, id_categoria)
        print(f"[{nome_categoria}] {len(produtos_da_categoria)} produtos")

        for id_produto, nome_produto in produtos_da_categoria:
            subpastas = dict(listar_subpastas(servico, id_produto))
            # subpastas = {"estampas": id, "produto no ambiente": id, ...}

            # pega a melhor imagem disponivel, na ordem de preferencia
            imagem_escolhida = None
            for nome_subpasta in SUBPASTAS_DE_FOTO:
                id_subpasta = subpastas.get(nome_subpasta)
                if not id_subpasta:
                    continue
                imagens = listar_imagens(servico, id_subpasta)
                if imagens:
                    imagem_escolhida = imagens[0]
                    break

            if not imagem_escolhida:
                print(f"  [!] {nome_produto}: sem foto ainda, pulando")
                continue

            caminho_local = PASTA_DOWNLOAD_LOCAL / f"p{contador:03d}_{imagem_escolhida['name']}"
            baixar_arquivo(servico, imagem_escolhida["id"], str(caminho_local))

            descricao_texto = ""
            id_pasta_descricao = subpastas.get("descrição")
            if id_pasta_descricao:
                descricao_texto = ler_descricao(servico, id_pasta_descricao)

            produtos.append({
                "id": f"p{contador:03d}",
                "categoria": nome_categoria,
                "nome": nome_produto,
                "tags": [nome_categoria.lower()],
                "cor_predominante": "",  # preencher manualmente se quiser mais precisao
                "descricao_tecnica": descricao_texto.strip(),
                "imagem_referencia": str(caminho_local),
            })
            print(f"  [ok] {nome_produto}")
            contador += 1

    return {"produtos": produtos}


if __name__ == "__main__":
    banco = montar_banco_de_produtos()

    with open("produtos_reais.json", "w", encoding="utf-8") as f:
        json.dump(banco, f, ensure_ascii=False, indent=2)

    print(f"\nConcluido! {len(banco['produtos'])} produtos salvos em produtos_reais.json")
    print("Proximo passo: usar esse arquivo no lugar de produtos_exemplo.json")

