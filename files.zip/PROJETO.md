# Projeto: Bot de conteúdo Instagram — IL Variedades Enxovais

## Objetivo geral
Criar um pipeline automatizado que:
1. Usa um banco de dados real de produtos (fotos/vídeos da loja)
2. Gera imagens/vídeos novos com a API do Gemini, baseados nesse banco
3. Monta o conteúdo final (carrossel ou reel, já formatado pro Instagram)
4. Publica automaticamente no Instagram, numa programação semanal fixa

## Sobre a marca
- Nome: IL Variedades — Enxovais & Lar
- Negócio familiar de enxovais desde 1999, na cidade de Elói Mendes, MG
- Público-alvo: 25+ anos, maior concentração no público feminino
- Diferenciais: relação com o cliente, atendimento personalizado, produtos de alta qualidade
- Categorias de produto: Cama, Mesa, Banho, Sofá, Infantil

## Identidade visual (seguir sempre)
- Roxo Nobre: #582C4D
- Rosa Quartzo: #C48B9F
- Off-White: #FAF9F6
- Conceito: monograma "il" + coração, traço fluido/caligráfico
- Tipografia: sans-serif moderna (peso forte no nome, peso leve no subtítulo)

## Tom de voz
- Elegante, caloroso, acolhedor, em primeira pessoa do plural ("nossos produtos")
- Emojis discretos: 🤍 💜 ✨
- CTA padrão: "Chame no direct e garanta o seu!"
- Hashtags fixas: #ilvariedades #Elegância #Sofisticação #Conforto

## Onde está o banco de dados de produtos
**JÁ EXISTE UM CATÁLOGO REAL E ESTRUTURADO NO DRIVE** (construído em sessão
anterior a 22-31/07/2026, mais completo do que se pensava inicialmente).

Estrutura confirmada (pasta raiz "produtos", ID: 14HEzU31Lu4ieHCLGgKrDFkHI3Q3lOcOk):
```
produtos/
  cama (quarto)/          -> lençol casal 4pçs, colcha preguiada, jogo de
                              quarto, cobertor/manta, colcha pique queen,
                              coberdrom, capas de colchão (4 tamanhos)
  banho (banheiro)/
  mesa (cozinha)/
  sofá (cortinas, tapetes e adereços)/
  infantil/
```
Cada pasta de produto contém até 4 subpastas: `estampas` (fotos cruas do
tecido), `produto no ambiente` (fotos em cena/decoração), `fotos variadas`,
e `descrição` (Google Doc com ficha técnica: descrição, modelo,
características, composição, peso, dimensão).

**Cobertura real**: nem todo produto tem todas as subpastas preenchidas
ainda (ex: "lençol casal 4 pçs" tem 10 fotos em estampas + 1 em produto no
ambiente + ficha técnica completa, mas "fotos variadas" está vazia). O
script `conectar_drive.py` já lida com isso automaticamente.

- `conectar_drive.py` — já configurado com o ID real da pasta "produtos".
  Ao rodar, varre todas as categorias e produtos, pega a melhor foto
  disponível de cada um (prioridade: produto no ambiente > estampas >
  fotos variadas), baixa localmente e gera `produtos_reais.json` incluindo
  a ficha técnica de cada produto (quando existir).
- `produtos_exemplo.json` — arquivo de teste com dados fictícios, não é
  mais necessário usar, pode ser descartado depois que produtos_reais.json
  funcionar.
- **Pendente**: só falta criar a conta de serviço no Google Cloud e
  compartilhar a pasta "produtos" com ela (passo a passo dentro do próprio
  conectar_drive.py).

## Mapa completo da pasta-mãe no Drive (confirmado em 04/08/2026)
Pasta raiz: "Enxovais Conteúdo Bot" (ID: 1Wg7o1JBo6MQPsZVGLH8m2yQ2Qsu7RNyo)

```
Enxovais Conteúdo Bot/
├── marca/                          [PREENCHIDA]
│   ├── identidade visual/
│   ├── tom de voz/
│   ├── sobre a loja/
│   └── dados de contato e redes/
│
├── produtos/                       [PARCIALMENTE PREENCHIDA -- catálogo real]
│   ├── cama (quarto)/  banho (banheiro)/  mesa (cozinha)/
│   ├── sofá (cortinas, tapetes e adereços)/  infantil/
│   (cada produto: estampas/ · produto no ambiente/ · fotos variadas/ · descrição/)
│
├── campanhas/                      [PREENCHIDA -- 23 campanhas com orientações]
│   ├── dia do consumidor/ (produtos-alvo/ · copy/ · referências visuais/)
│   ├── dia das mulheres/  dia das mães/  dia das crianças/  dia dos namorados/
│   ├── primavera/  verão/  outono/  inverno/
│   ├── black friday/  natal/
│   ├── dia 1 do 1/  dia 2 do 2/  dia 3 do 3/  dia 4 do 4/  dia 5 do 5/
│   │   dia 6 do 6/  dia 7 do 7/  dia 8 do 8/  dia 9 do 9/  dia 10 do 10/
│   │   dia 11 do 11/  dia 12 do 12/  (promoções relâmpago mensais)
│   (cada pasta de campanha tem um doc "orientações-campanha": período,
│   cores, temática, categorias/produtos prioritários, tom de voz
│   específico, CTA, hashtags extras e referência visual)
│
└── referências e exemplos/         [SÓ ESTRUTURA, VAZIA]
    ├── exemplo de carrosséis/
    ├── copy's para vídeos/
    └── ambientes/
```

**Implicação para a programação semanal do bot:** existem 23 campanhas ao
todo -- 11 sazonais/datas comemorativas (Dia das Mulheres, Dia das Mães,
Dia do Consumidor, Outono, Dia dos Namorados, Inverno, Primavera, Dia das
Crianças, Black Friday, Verão, Natal) e 12 promoções relâmpago mensais
recorrentes ("Dia X do X", uma por mês, ex: 9/9, 10/10, 11/11, 12/12).
Cada uma tem um documento "orientações-campanha" com período, cores,
temática, categorias/produtos prioritários, tom de voz específico, CTA e
referência visual. O agendador semanal deve verificar se alguma campanha
está no período ativo (as mensais são sempre no dia N do mês N; as outras
têm janelas maiores) e priorizar as orientações daquela pasta em vez do
fluxo genérico. Quando cai numa mesma semana mais de uma campanha (ex:
Dia 5 do 5 no mesmo mês do Dia das Mães), as orientações já foram escritas
cruzando as duas intencionalmente. As subpastas "produtos-alvo", "copy" e
"referências visuais" de cada campanha ainda estão vazias -- servem para
quando o usuário quiser deixar algo pronto com antecedência, mas não são
obrigatórias: na ausência delas, o bot usa as orientações gerais do doc
principal.

## Status atual do projeto (o que já foi feito)
- [x] Identidade visual documentada (cores, tipografia, conceito)
- [x] Tom de voz documentado com exemplos reais de legendas antigas
- [x] Dados de contato e endereço confirmados
- [x] Script de geração de imagem via Gemini criado e testado (funciona,
      mas hoje só com dados fictícios de exemplo)
- [x] Catálogo real de produtos já existe e mapeado no Drive (fotos +
      ficha técnica), estrutura confirmada em 04/08/2026
- [x] Script de conexão com Google Drive atualizado para ler a estrutura
      real (conectar_drive.py) -- falta só configurar a conta de serviço
- [ ] Montagem do carrossel (overlay de texto tipo "COLCHA MATELADA CASAL",
      no padrão que a loja já usava antes)
- [ ] Conexão com a Instagram Graph API (conta Business + App aprovado na Meta)
- [ ] Upload das imagens geradas para um storage público (S3/GCS/Cloudinary)
      -- necessário porque a API do Instagram só aceita publicar a partir
      de uma URL pública, não upload direto de arquivo
- [ ] Agendador (cron) rodando o pipeline inteiro uma vez por semana
- [x] Orientações das 23 campanhas definidas e documentadas dentro de
      cada pasta no Drive (11 sazonais/datas comemorativas + 12
      promoções relâmpago mensais "Dia X do X")

## Próximo passo imediato
1. Configurar a conta de serviço no Google Cloud e compartilhar a pasta
   "produtos" (ID: 14HEzU31Lu4ieHCLGgKrDFkHI3Q3lOcOk) com ela (passo a
   passo dentro de conectar_drive.py).
2. Rodar conectar_drive.py para gerar produtos_reais.json.
3. Trocar produtos_exemplo.json por produtos_reais.json dentro de
   gerar_carrossel_gemini.py, e aproveitar a ficha técnica (descricao_tecnica)
   para enriquecer os prompts de geração de imagem.
